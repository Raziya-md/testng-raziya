package javaprogramme1;

public class assignmentoperators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//assigning operators (=,+=,-=,*=,)
		 	 	short employees = 500;
		 	 	System.out.println(employees);  //500
		 	 	
		 	 	employees += 500;
		 	 	System.out.println(employees);  //1000  LHS+RHS  500+500
		 	 	
		 	 int male= 200;
		 	 male -= 100;
		 	 	System.out.println(male);  //100  whereLHS-RHS  200-100
		 	 	
		 	 	int female =300;
		 	 	female *= 150;
		 	 	System.out.println(female);  //45000  300*150
		 	 	
		 	 	
		 	 	
		 	 	
		 	 	

	}

}
