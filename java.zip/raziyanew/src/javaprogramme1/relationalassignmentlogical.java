package javaprogramme1;

public class relationalassignmentlogical {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
		//relational operators (==,<=,>=,<,>,!=,)
		
		int productA =200;
		int productB = 500;
		int productC =700;
		int productD = (productA+productB);
		System.out.println(productD>productB);   // TRUE
		System.out.println(productC == productD);  //TRUE
		System.out.println(productC>=productD);   //TRUE
		System.out.println(productC<=productD);    //TRUE
		System.out.println(productB>productC);   //FALSE
		System.out.println(productA<productC);   //TRUE
		System.out.println(productC>productD);  //FALSE
		System.out.println(productB<=productA);  //FALSE
		System.out.println(productA!=productB);   //TRUE
		System.out.println(productD!=productC);   //FALSE
		System.out.println(productC!=productB);  //true
		System.out.println(productD!=productC);  //false
		
	
		
		
		
		
		
		
		
		
		
		


			

	}

}
