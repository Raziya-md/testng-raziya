package javapragramme;

public class relationaloperators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a = 100;
int b = 200;
int c = 100;
System.out.println(a==c);  //true
System.out.println(a!=b);  //true
System.out.println(b>c);  //true
System.out.println(a>b);  //false
System.out.println(a<=c); //true
System.out.println(c>=b);  //false


	}

}
