package javapragramme;  //Java package Name

public class datatypes { //Java class Name

	public static void main(String[] args) {     //Main Method
		Byte age = 20; //Declaration and Assigned the value
		short number1 = 3034;
		int age3 = 6305064;
		
        System.out.println(age);
        System.out.println(number1);
        System.out.println(age3);
        
        //Declaration of all the variables which we need
        int pincode;
        int number;
        int accountnumber;
        long mobilenumber;
        
        //Assigning the values
        pincode = 506381;
        number = 543;
        accountnumber = 06432;
        mobilenumber = 6305013;
        		
        System.out.println(pincode);
        System.out.println(number);
        System.out.println(accountnumber);
        System.out.println(mobilenumber);
        
        
        //Declare other way....
        int  add1,add2,add3;
        long mob1,mob2,mob3;
        
        add1=10;
        mob1=1234;
        
        System.out.println(add1);
        System.out.println(mob1);
        
        
        
        double height = 5.9; //smaller
        double transnum = 1004.5677;
        float decnum =10.55f;
        
        System.out.println(height);
        System.out.print(transnum);
        System.out.print(decnum);
        
        
        char gender = 'm';
        char colorcode = 'g';
        char yes = '1';
        char sysmbol = '@';
        System.out.println(gender);
        System.out.println(colorcode);
        System.out.println(yes);
        
        boolean isTelanganainIndia1 = true;
        boolean isHydInUSA = false;
        System.out.println(isTelanganainIndia1);
        System.out.println(isHydInUSA);
        
        int xxx = 1234567899;
        System .out.println(xxx);
       
        byte b = 127; //>-127 to +127 byte will not store
        short s = 32767;  //>32767 short capacity range max
              
        
        
        long value = 12348769014567893L;
        System.out.println(value);
        
        		
        		
        
	}

}
