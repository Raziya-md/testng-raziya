package assignmentmaven;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class links {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Program Files (x86)\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		String Url ="https://rahulshettyacademy.com/locatorspractice/";
driver.get(Url);
		System.out.println(driver.getCurrentUrl());
		WebElement linktext=driver.findElement(By.linkText("Forgot your password?"));
		linktext.click();
		WebElement partiallinktext=driver.findElement(By.partialLinkText("Forgot"));
		partiallinktext.click();
		driver.close();
		
		
		
	}

}
