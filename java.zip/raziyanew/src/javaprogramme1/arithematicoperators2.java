package javaprogramme1;

public class arithematicoperators2 {

	public static void main(String[]args) {
		System.out.println("raziya");
		int a =1000;
		byte b = 112;
		int c= a+b;
		System.out.println(a+b);
		System.out.println(a-b);
		System.out.println(a*b);
		System.out.println(a/b);
		System.out.println(a%b);	
		System.out.println(c);
		System.out.println(c+a-b);
		System.out.println(c-a+b);
		System.out.println(c/a);
		System.out.println(c%a);
		
		System.out.println("raziya print");
		byte raziya = 76;
		System.out.println(++raziya);
		System.out.println(raziya++);
		System.out.println(raziya);
		System.out.println(raziya++);
		System.out.println(raziya);
		System.out.println(++raziya);
		int v= 200;
		int m= 10;
		System.out.println(v/m);
		System.out.println(m/v);
		float d = 50;
		float r = 30;
		float e =25;
		System.out.println(r/e);
		System.out.println(e%d);
		System.out.println(e/r);
		
		
		
	}

}
