package javaprogramme1;  //Java package name

public class datatype1 {   //Java class name

	public static void main(String[] args) {   //Main Method
		System.out.println("Raziya");
		
		short number =10;   //declaration and assigning the values
		System.out.println(number);
		byte age =9;
		System.out.println(age);
		long mobilenumber = 63050643;
		int account = 8875;
		System.out.println(mobilenumber);
		System.out.println(account);
		byte add1;   //declaring the datatype values
		short transnum; 
		add1 =12;  //assigning the values
		transnum = 123;
		System.out.println(add1);
		System.out.println(transnum);
		double height= 5.2;
		double decnum = 100.234567;
		float deci = 8.55f;
		System.out.println(height);
		System.out.println(decnum);
		System.out.println(deci);
		char gender = 'f';
		char colorcode = 'p';
		System.out.println(gender);
		System.out.println(colorcode);
		boolean istelanganainindia = true;
		boolean hydisinUSA =false;
		System.out.println(istelanganainindia);
		System.out.println(hydisinUSA);
		
		long mobnum =630506431;
		System.out.println(mobnum);
		
		

	}

}
