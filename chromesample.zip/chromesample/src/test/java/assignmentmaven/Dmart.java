package assignmentmaven;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Dmart {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Program Files (x86)\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver Driver = new ChromeDriver();
		Driver.manage().window().maximize();
		Driver.get("https://www.dmart.in/category/dmart-grocery-aesc-grocerycore2");
		//Driver.findElement(By.className("MuiGrid-root MuiGrid-item MuiGrid-grid-xs-12 MuiGrid-grid-sm-6 MuiGrid-grid-md-4 MuiGrid-grid-lg-auto MuiGrid-grid-xl-auto mui-style-tlgnrr"));
		//Driver.findElement(By.className("cart-action_action-label__iNzbC")).click();
		Driver.findElement(By.xpath("//button[@title='SignIn / Register']")).click();
		Driver.findElement(By.name("mobileNumber")).sendKeys("6305064313");
		Driver.findElement(By.xpath("//button[@type='submit']")).click();
		Driver.findElement(By.name("firstName")).sendKeys("Raziya");
		Driver.findElement(By.name("lastName")).sendKeys("Sulthana");
		Driver.findElement(By.xpath("//button[@type='submit']")).click();
		
	}

}
