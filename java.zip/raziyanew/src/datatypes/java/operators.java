package datatypes.java;

public class operators {

	public static void main(String[] args) {
		

	}

}
